# Proyecto_PA-POO - Grupo 4
Avance curricular
Gestión de avance curricular de los alumnos en un institutoRegistro de alumnos, profesores, asignaturas y de nivel de avance de un alumno dependiendo de su avance en la malla.
Integrantes:
 Pablo Torreblanca L. (Ejecución)
 Fernando Melillán T. (Civil)
 Beatriz Segura P. (Civil)
