/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package avancecurricular;
import javax.swing.*;
import java.util.*;
/**
 *
 * @author beatr
 */
public class Asignatura {
    private int id;
    private String nombre;
    private int semestre;
    private int creditos;
    private ArrayList <Asignatura> asignaturasPrerequisitos;
    private ArrayList <Modulo> modulos;
    private ArrayList <String> asignaturas = new ArrayList<String>();

    //Constructor
    public Asignatura(int id, String nombre, int semestre, int creditos){
        this.id = id;
        this.nombre = nombre;
        this.semestre = semestre;
        this.asignaturasPrerequisitos = new ArrayList<>();
        this.modulos = new ArrayList<>();
        this.asignaturas = new ArrayList<>();
            
    }

    //Get y set
    public int getSemestre(){
        return semestre;
    }

    public void setSemestre(int semestre){
        this.semestre = semestre;
    }

    public String getNombre(){
        return nombre;
    }

    public void setNombre(String nombre){
        this.nombre = nombre;
    }

     public int getCreditos(){
        return creditos;
    }

    public void setCreditos(int creditos){
        this.creditos = creditos;
    }

    public int getId(){
        return id;
    }

    public ArrayList<String> getAsignaturas() { return asignaturas; }

    public void setAsignaturas(ArrayList<String> asignaturas) { this.asignaturas = asignaturas; }

    public ArrayList<Asignatura> getAsignaturasPrerequisitos(){
        return asignaturasPrerequisitos;
    }
    
    public ArrayList<Modulo> getModulos(){
        return modulos;
    }

    public void mostrarAsignatura(){
        System.out.println(this.id+"  "+this.nombre);
    }

    public void agregarPrerequisito(Asignatura a){
        this.asignaturasPrerequisitos.add(a);
    }
    
    public void agregarMoodulo(Modulo a){
        this.modulos.add(a);
    }
    
    public void mostrarPrerequisitos(){
        for(int i=0;i<this.asignaturasPrerequisitos.size();i++){
            this.asignaturasPrerequisitos.get(i).mostrarAsignatura();
        }
    }
    
    public void mostrarModulos(){
        for(int i=0;i<this.modulos.size();i++){
            this.modulos.get(i).mostrarModulo();
        }
    }
    
    public void removeModulo(Modulo m){
        for(int i=0;i<this.modulos.size();i++){
            if(this.modulos.get(i).getIdModulo()== m.getIdModulo()){
                this.modulos.remove(this.modulos.get(i));
                return;
            }
        }
        
    }

    private static void modificarAsignatura(ArrayList asignaturas){
        String opcion;
        String editar;
        do{
            opcion = JOptionPane.showInputDialog(" ¿ Desea modificar una asignatura ?, para ello escriba 'si' ");
            editar = JOptionPane.showInputDialog("Escriba la asignatura a editar");
            ArrayList <String> modi = new ArrayList<>();
            for (int j = 0; j < asignaturas.size();j++){
                modi.add(editar);
            }
            if (opcion == "si" || opcion == "Si" || opcion == "sI" || opcion== "SI") {
                for (int i = 0; i < asignaturas.size(); i++)
                    if () {
                        editar = String.valueOf(asignaturas.equals(i));
                    }
            }
        }while (opcion == "si" || opcion == "Si" || opcion == "sI" || opcion== "SI");
    }






    private static void eliminarAsignatura(ArrayList asignaturas, Malla malla){
        String opcion;

        String aEliminar;
        do{
            opcion = JOptionPane.showInputDialog(" ¿ Desea eliminar una carrea ?, para ello escriba si ");
            aEliminar = JOptionPane.showInputDialog("Escriba la carrera a eliminar");
            ArrayList <String> elimi = new ArrayList<String>();

            for (int j = 0;j < asignaturas.size() ;j++){
                elimi.add(aEliminar);
            }

            if (opcion == "si"|| opcion == "SI" || opcion == "sI" || opcion == "Si") {
                if(aEliminar == malla.getNombreCarrera()) {
                    for (int i = 0; i < asignaturas.size(); i++) {
                        if (elimi.get(i) == asignaturas.get(i)) {
                            asignaturas.remove(aEliminar);
                        }
                    }
                }
            }
        }while (opcion == "si"|| opcion == "SI" || opcion == "sI" || opcion == "Si");
        System.out.print("La eliminacion fue exitosa");
    }


}
