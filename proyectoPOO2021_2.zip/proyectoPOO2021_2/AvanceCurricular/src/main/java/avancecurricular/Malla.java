/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package avancecurricular;
import javax.swing.*;
import java.util.*;
/**
 *
 * @author beatr
 */
public class Malla {
    private String nombreCarrera;
    private int cantSemestres;
    ArrayList <Asignatura> asignaturas;

    //Constructor
    public Malla(String carrera, int semestres){
        nombreCarrera = carrera;
        cantSemestres = semestres;
        this.asignaturas = new ArrayList<>();
    }

    //Get y set
    public int getCantSemestres(){
        return cantSemestres;
    }

    public void setCantSemestres(int semestres){
        cantSemestres = semestres;
    }

    public String getNombreCarrera(){
        return nombreCarrera;
    }

    public void setNombreCarrera(String carrera){
        nombreCarrera = carrera;
    }

    public void agregarAsignatura(Asignatura a){
        this.asignaturas.add(a);
    }

    //Sobrecarga de metodos

    public void mostrarAsignaturas(){
        for(int i=0;i<this.asignaturas.size();i++){
            this.asignaturas.get(i).mostrarAsignatura();
        }
    }

    public void mostrarAsignaturas(String nombreAsignatura){
        for(int i=0;i<this.asignaturas.size();i++){
            if (this.asignaturas.get(i).getNombre().equals(nombreAsignatura)){
            this.asignaturas.get(i).mostrarAsignatura();
            }
        }
    }

    public void mostrarAsignaturas(int id){
        for(int i=0;i<this.asignaturas.size();i++){
            if (this.asignaturas.get(i).getId()==id){
            this.asignaturas.get(i).mostrarAsignatura();
            }
        }
    }



    private static void modificarCarrera(Malla malla, ArrayList asignaturas){
        String opcion;
        String editar;
        String editarNom, editarCantS, editarAsig;
        do{
            opcion = JOptionPane.showInputDialog(" ¿ Desea modificar una carrea ?, para ello escriba 'si' ");
            editar = JOptionPane.showInputDialog("Escriba la carreara a editar");
            ArrayList <String> modi = new ArrayList<>();
            for (int j = 0; j < asignaturas.size();j++){
                modi.add(editar);
            }

            if (opcion == "si" || opcion == "Si" || opcion == "sI" || opcion== "SI") {
                for (int i = 0; i <asignaturas.size() ; i++)
                    if (asignaturas.get(i) == modi.get(i)){           //en este if es para confirmar que entre la info y empezar a modificar pero me estanque y me quede un poco sin ideas
                        asignaturas.remove(asignaturas.get(malla.getCantSemestres(modi.get())));
                        editarCantS = asignaturas.get(malla.setCantSemestres());
                        asignaturas.add(editarCantS);
                        asignaturas.remove(asignaturas.get());
                        editarNom = asignaturas.get();
                        asignaturas.add(editarNom);
                    }
            }
        }while (opcion == "si" || opcion == "Si" || opcion == "sI" || opcion== "SI");
    }






    private static void eliminarCarrera(ArrayList asignaturas, Malla malla){
        String opcion;

        String aEliminar;
        do{
            opcion = JOptionPane.showInputDialog(" ¿ Desea eliminar una carrea ?, para ello escriba si ");
            aEliminar = JOptionPane.showInputDialog("Escriba la carrera a eliminar");
            ArrayList <String> elimi = new ArrayList<String>();

            for (int j = 0;j < asignaturas.size() ;j++){
                elimi.add(aEliminar);
            }

            if (opcion == "si"|| opcion == "SI" || opcion == "sI" || opcion == "Si") {
                if(aEliminar == malla.getNombreCarrera()) {
                    for (int i = 0; i < asignaturas.size(); i++) {
                        if (elimi.get(i) == asignaturas.get(i)) {
                            asignaturas.remove(aEliminar);
                        }
                    }
                }
            }
        }while (opcion == "si"|| opcion == "SI" || opcion == "sI" || opcion == "Si");
        System.out.print("La eliminacion fue exitosa");
    }

}
